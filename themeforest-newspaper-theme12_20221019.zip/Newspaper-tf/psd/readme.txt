use 7zip (open source) to unzip the psd files (psd.7z) http://www.7-zip.org/

